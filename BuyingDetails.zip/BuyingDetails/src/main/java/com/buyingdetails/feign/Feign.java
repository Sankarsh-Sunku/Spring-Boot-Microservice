package com.buyingdetails.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.buyingdetails.beans.CustomerBean;

@FeignClient(name = "CustFeign",url = "http://localhost:8082/customer")
public interface Feign {
	@GetMapping("/getCustomerById/{customerId}")
	public CustomerBean getCustomerById(@PathVariable int customerId);

}
