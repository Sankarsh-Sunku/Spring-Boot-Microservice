package com.buyingdetails.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.buyingdetails.beans.ReferralBean;

@FeignClient(name = "referralService",url = "http://localhost:8086/referral")
public interface Feign2 {
	@PutMapping("/updateref/{referralId}")
	public String updateReferralById(@PathVariable long referralId,@RequestBody ReferralBean referralBean);
	@GetMapping("/showref/{referralId}")
	public ReferralBean getReferralById(@PathVariable long referralId);
	@PostMapping("/addref/{userId}")
	public String generateReferral(@PathVariable int userId,@RequestBody ReferralBean bean);
}
