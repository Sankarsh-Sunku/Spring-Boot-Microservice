package com.buyingdetails.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.buyingdetails.entities.BuyingDetailsEntity;

public interface BuyingDetailsDao extends JpaRepository<BuyingDetailsEntity, Integer>{

	@Query("SELECT e FROM BuyingDetailsEntity e WHERE e.userId = ?1")
	public Optional<BuyingDetailsEntity> findByUserId(int userId);
	@Modifying
	@Query("DELETE FROM BuyingDetailsEntity e WHERE e.userId = ?1")
	public void deletedetailsByUserId(int userId);
}
