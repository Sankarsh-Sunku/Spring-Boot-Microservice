package com.buyingdetails.service;

import java.util.List;

import com.buyingdetails.beans.BuyingDetails;
import com.buyingdetails.beans.CustomerBean;

public interface BuyingDetailsService {
	public String addDetails(BuyingDetails bean,CustomerBean customerBean);
	public BuyingDetails getDetailsById(int purchaseId);
	public String removeDetailsById(int purchaseId);
	public String updateDetailsById(int purchaseId,BuyingDetails bean);
	public List<BuyingDetails> getAllDetails();
	public String deleteDetailsByUserId(int userId);
}
