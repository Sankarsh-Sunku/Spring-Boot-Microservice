package com.buyingdetails.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.naming.java.javaURLContextFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.buyingdetails.beans.BuyingDetails;
import com.buyingdetails.beans.CustomerBean;
import com.buyingdetails.dao.BuyingDetailsDao;
import com.buyingdetails.entities.BuyingDetailsEntity;

import jakarta.transaction.Transactional;

@Service
public class BuyingDetailsServiceImpl implements BuyingDetailsService{
	
	@Autowired
	private BuyingDetailsDao dao;

	@Override
	public String addDetails(BuyingDetails bean,CustomerBean customerBean) {
		// TODO Auto-generated method stub
		if(customerBean!=null) {
			bean.setCustomerId(customerBean.getCustomerId());
			bean.setUserId(customerBean.getUserId());
			bean.setPurchaseDate(java.time.LocalDate.now());
			if(customerBean.getReferralCode()!=0) {
				bean.setStatus("Referral Accepted");
				BuyingDetailsEntity entity = new BuyingDetailsEntity();
				BeanUtils.copyProperties(bean, entity);
				dao.save(entity);
				return "Data Successfully Added With Referral";
			}else {
				bean.setStatus("Referral Not Accepted");
				BuyingDetailsEntity entity = new BuyingDetailsEntity();
				BeanUtils.copyProperties(bean, entity);
				dao.save(entity);
				return "Data Successfully Added Without Referral";
			}
		}else {
			return "Check Entered Data";
		}
	}

	@Override
	public BuyingDetails getDetailsById(int purchaseId) {
		// TODO Auto-generated method stub
		BuyingDetails bean = new BuyingDetails();
		Optional<BuyingDetailsEntity> container = dao.findById(purchaseId);
		BeanUtils.copyProperties(container.get(), bean);
		return bean;
		
	}

	@Override
	public String removeDetailsById(int purchaseId) {
		// TODO Auto-generated method stub
		Optional<BuyingDetailsEntity> container = dao.findById(purchaseId);
		if(container.isPresent()) {
			dao.deleteById(purchaseId);
			return "Entry With PurchaseId " + purchaseId +  " Deleted Successfully";
		}else {
			return "Check Entered PurchaseId";
		}
	}

	@Override
	public String updateDetailsById(int purchaseId, BuyingDetails bean) {
		// TODO Auto-generated method stub
		Optional<BuyingDetailsEntity> container1 = dao.findById(purchaseId);
		Optional<BuyingDetailsEntity> container2 = dao.findById(bean.getPurchaseId());
		BuyingDetailsEntity entity = container1.get();
		if(container1 == container2 && container1!=null && container2!=null ) {
			entity.setCustomerId(bean.getCustomerId());
			entity.setUserId(bean.getUserId());
			entity.setPurchaseDate(bean.getPurchaseDate());
			entity.setProductName(bean.getProductName());
			dao.save(entity);
			return "Successfully Updated the Details";
		}else {
			return "Check Entered PurchaseId";
		}
		
	}

	@Override
	public List<BuyingDetails> getAllDetails() {
		// TODO Auto-generated method stub
		List<BuyingDetailsEntity> listEntities = dao.findAll();
		List<BuyingDetails> list = new LinkedList<BuyingDetails>();
		listEntities.forEach(x -> {
			BuyingDetails bean = new BuyingDetails();
			BeanUtils.copyProperties(x, bean);
			list.add(bean);
		});
		return list;
	}
	
	@Override
	@Transactional
	public String deleteDetailsByUserId(int userId) {
		Optional<BuyingDetailsEntity> entity = dao.findByUserId(userId);
		if(entity.isPresent()) {
			dao.deletedetailsByUserId(userId);
			return "Successfully deleted";
		}
		else {
			return "check the userId";
		}
	}
}
