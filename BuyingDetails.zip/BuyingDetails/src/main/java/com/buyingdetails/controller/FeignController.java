package com.buyingdetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.buyingdetails.beans.CustomerBean;
import com.buyingdetails.beans.ReferralBean;
import com.buyingdetails.feign.Feign;
import com.buyingdetails.feign.Feign2;

@RestController
public class FeignController {
	@Autowired
	private Feign feign;
	
	@Autowired
	private Feign2 feign2;
	
	@GetMapping("getCustomer/{customerId}")
	public CustomerBean getCustomer(@PathVariable int customerId) {
		CustomerBean bean = feign.getCustomerById(customerId);
		return bean;
	}
	
	@GetMapping("getReferral/{referralId}")
	public ReferralBean getReferral(@PathVariable long referralId) {
		ReferralBean bean =  feign2.getReferralById(referralId);
		return bean;
	}
	
	@PutMapping("updateReferral/{referralId}")
	public String updateReferral(@PathVariable long referralId,@RequestBody ReferralBean referralBean) {
		String msg = feign2.updateReferralById(referralId, referralBean);
		return msg;
	}
	
	@PostMapping("generateRef/{userId}")
	public String generateReferral(@PathVariable int userId,@RequestBody ReferralBean bean) {
		String msg = feign2.generateReferral(userId,bean);
		return msg;
	}
	
}
