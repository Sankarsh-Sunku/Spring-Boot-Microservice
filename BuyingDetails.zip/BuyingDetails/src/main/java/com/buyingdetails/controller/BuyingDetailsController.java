package com.buyingdetails.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.buyingdetails.beans.BuyingDetails;
import com.buyingdetails.beans.CustomerBean;
import com.buyingdetails.beans.ReferralBean;
import com.buyingdetails.service.BuyingDetailsServiceImpl;

@RestController
@RequestMapping("productDetails")
public class BuyingDetailsController {

	@Autowired
	private BuyingDetailsServiceImpl service;
	
	@Autowired
	private FeignController fyn;
	
	@PostMapping("/addDetails/{customerId}")
	public ResponseEntity<?> addDetails(@RequestBody BuyingDetails bean,@PathVariable int customerId){
		Map<String, Object> map = new LinkedHashMap<>();
		CustomerBean customerBean = fyn.getCustomer(customerId);
		String msg = service.addDetails(bean,customerBean);
		map.put("status", msg);
		ReferralBean referralBean = new ReferralBean();
		if(customerBean.getReferralCode()!=0) {
		referralBean = fyn.getReferral(customerBean.getReferralCode());
//		if(msg == "Data Successfully Added With Referral") {
			int points = referralBean.getReferralPoints() + 1000;
			int id = customerBean.getUserId();
			String str = referralBean.getStatus();
			String x1 = "Referred";
			
			if(str == "notReferred") {
				referralBean.setStatus(x1 + " "+customerBean.getUserId());
			}
			referralBean.setReferralPoints(points);
			String x = fyn.updateReferral(customerBean.getReferralCode(), referralBean);
			ReferralBean referralBean2 = new ReferralBean();
			String msg2 = fyn.generateReferral(customerBean.getUserId(),referralBean2);
			map.put("status of referral", x);
		}else {
		String msg2 = fyn.generateReferral(customerBean.getUserId(),referralBean);
		map.put("status of referral", msg2);
		}
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	@GetMapping("/getDetailsById/{purchaseId}")
	public ResponseEntity<?> getDetailsById(@PathVariable int purchaseId){
		BuyingDetails bean = service.getDetailsById(purchaseId);
		Map<String, Object> map = new LinkedHashMap<>();
		if(bean!=null) {
			map.put("BuyingDetails", bean);
			return new ResponseEntity<>(map,HttpStatus.FOUND);
		}else
		{
			map.put("status", "Not Found");
			return new ResponseEntity<>(map,HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/updateDetailsById/{purchaseId}")
	public ResponseEntity<?> updateDetailsById(@PathVariable int purchaseId,@RequestBody BuyingDetails bean){
		Map<String, Object> map = new LinkedHashMap<>();
		String msg = service.updateDetailsById(purchaseId, bean);
		map.put("status", msg);
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	@DeleteMapping("/removeDetailsById/{purchaseId}")
	public ResponseEntity<?> removeDetailsById(@PathVariable int purchaseId){
		String msg = service.removeDetailsById(purchaseId);
		Map<String, Object> map = new LinkedHashMap<>();
		map.put("status", msg);
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	@GetMapping("/getAllDetails")
	public ResponseEntity<?> getAllDetails(){
		List<BuyingDetails> list = service.getAllDetails();
		Map<String, Object> map = new LinkedHashMap<>();
		if(list!=null) {
			map.put("ListOfUsers", list);
			return new ResponseEntity<>(map,HttpStatus.OK);
		}else {
			map.put("Status", "There is No data Found");
			return new ResponseEntity<>(map,HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/deleteDetailsByUserId/{userId}")
	public ResponseEntity<?> deleteDetailsByUserId(@PathVariable int userId){
		String msg = service.deleteDetailsByUserId(userId);
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
}
