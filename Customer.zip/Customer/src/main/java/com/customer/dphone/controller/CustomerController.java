package com.customer.dphone.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.customer.dphone.beans.CustomerBean;
import com.customer.dphone.beans.ReferralBean;
import com.customer.dphone.beans.UserBean;
import com.customer.dphone.service.CustomerServiceImpl;


@RestController
@RequestMapping("customer")
public class CustomerController {
	//private static final String USER_SERVICE = "userService";
	@Autowired
	private CustomerServiceImpl service;
	@Autowired
	private FeignController feign;

	@RequestMapping(
			value = "/addCustomer/{userId}/{referralId}",
			method=RequestMethod.POST,
			produces = "application/json",
			consumes = "application/json")
	public ResponseEntity<?> addCustomer(@RequestBody CustomerBean customerBean,@PathVariable int userId,@PathVariable int referralId) {
		UserBean userBean = feign.getUserId(userId);
		ReferralBean referralBean = new ReferralBean();
		referralBean = feign.getReferral(referralId);
		String msg;
		if(referralBean!=null) {
			msg = service.addCustomer(customerBean,userBean,referralId);
		}
		else {
			msg = service.addCustomer(customerBean,userBean,0);
		}
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		map.put("status", msg);
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	@RequestMapping(
			value = "/deleteCustomerById/{customerId}",
			method=RequestMethod.DELETE,
			produces = "application/json")
	public ResponseEntity<?> removeCustomer(@PathVariable int customerId){
		String msg = service.removeCustomer(customerId);
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		map.put("status", msg);
		return new ResponseEntity<>(map,HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/getCustomerById/{customerId}",
			method = RequestMethod.GET,
			produces = "application/json")
	public ResponseEntity<?> getCustomerById(@PathVariable int customerId){
		CustomerBean bean = new CustomerBean();
		bean = service.getCustomerById(customerId);
		return new ResponseEntity<>(bean,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updateCustomerById/{customerId}",
			method = RequestMethod.PUT,
			produces = "application/json",
			consumes = "application/json")
	public ResponseEntity<?> updateCustomerById(@RequestBody CustomerBean bean,@PathVariable int customerId){
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		String msg = service.updateCustomerById(customerId, bean);
		map.put("status", msg);
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllCustomers",
			method = RequestMethod.GET,
			produces = "application/json")
	public ResponseEntity<?> getAllCustomers(){
		List<CustomerBean> list = service.getAllCustomers();
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		if(list.isEmpty()) {
			map.put("Status", "There is No Data Found");
			return new ResponseEntity<>(map,HttpStatus.NOT_FOUND);
		}else {
			map.put("ListOfCustomers", list);
			return new ResponseEntity<>(map,HttpStatus.FOUND);
		}
		
	}
	
	@DeleteMapping("deleteCustByUser/{userId}")
	public ResponseEntity<?> deleteByUserId(@PathVariable int userId){
		return new ResponseEntity<>(service.deleteCustByUserId(userId),HttpStatus.OK);
	}
	
	@GetMapping("getCustByUserId/{userId}")
	public ResponseEntity<?> getCustByUserId(@PathVariable int userId){
		return new ResponseEntity<>(service.getCustomerByUserId(userId),HttpStatus.OK);
	}
	
	@PutMapping("updateCustByUserId/{userId}")
	public ResponseEntity<?> updateCustByUserId(@PathVariable int userId,@RequestBody CustomerBean bean){
		return new ResponseEntity<>(service.updateCustomerByUserId(userId, bean),HttpStatus.OK);
	}
	
//	public ResponseEntity<?> userFallback(Exception e){
//		return new ResponseEntity<>("Service is temporarily Down",HttpStatus.ACCEPTED);
//	}
	
	
}
