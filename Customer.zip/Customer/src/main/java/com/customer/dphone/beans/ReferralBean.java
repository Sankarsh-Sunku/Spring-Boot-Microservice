package com.customer.dphone.beans;

public class ReferralBean {
	private long referralId;
	private String referralFirstName;
	private String referralLastName;
	private long mobile;
	private String email;
	private String dateOfReferral;
	private String status;
	private int userId;
	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getReferralFirstName() {
		return referralFirstName;
	}

	public void setReferralFirstName(String referralFirstName) {
		this.referralFirstName = referralFirstName;
	}

	public String getReferralLastName() {
		return referralLastName;
	}

	public void setReferralLastName(String referralLastName) {
		this.referralLastName = referralLastName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDateOfReferral() {
		return dateOfReferral;
	}

	public void setDateOfReferral(String dateOfReferral) {
		this.dateOfReferral = dateOfReferral;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getReferralId() {
		return referralId;
	}

	public void setReferralId(long referralId) {
		this.referralId = referralId;
	}

	@Override
	public String toString() {
		return "ReferralBean [referralId=" + referralId + ", referralFirstName=" + referralFirstName
				+ ", referralLastName=" + referralLastName + ", mobile=" + mobile + ", email=" + email
				+ ", dateOfReferral=" + dateOfReferral + ", status=" + status + ", userId=" + userId + "]";
	}
	
	
}
