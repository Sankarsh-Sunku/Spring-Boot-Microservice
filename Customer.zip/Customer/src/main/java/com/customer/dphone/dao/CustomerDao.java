package com.customer.dphone.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.customer.dphone.entities.CustomerEntity;


import java.util.Optional;
public interface CustomerDao extends JpaRepository<CustomerEntity, Integer>{
	
	@Query("SELECT c FROM CustomerEntity c WHERE c.userId = ?1")
	public Optional<CustomerEntity> findByUserId(int userId);
	@Modifying
	@Query("DELETE FROM CustomerEntity c WHERE c.userId = :userId")
	public void deleteByUserId(@Param("userId") int userId);

}
