package com.customer.dphone.service;

import java.util.List;


import com.customer.dphone.beans.CustomerBean;
import com.customer.dphone.beans.ReferralBean;
import com.customer.dphone.beans.UserBean;

public interface CustomerService {
	public String addCustomer(CustomerBean customer,UserBean userBean,int referralId);
	public String removeCustomer(int customerId);
	public CustomerBean getCustomerById(int customerId);
	public String updateCustomerById(int customerId,CustomerBean customer);
	public List<CustomerBean> getAllCustomers();
	public String deleteCustByUserId(int userId);
	public CustomerBean getCustomerByUserId(int userId);
	public String updateCustomerByUserId(int userId,CustomerBean bean);

}
