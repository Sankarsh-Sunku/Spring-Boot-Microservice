package com.customer.dphone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.dphone.beans.ReferralBean;
import com.customer.dphone.beans.UserBean;
import com.customer.dphone.feign.ClientFeign;
import com.customer.dphone.feign.ClientFeign2;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("feign")
public class FeignController {

	private static final String CUSTOMER_SERVICE = "customerFeignService";
	
	@Autowired
	private ClientFeign feign;
	@Autowired
	private ClientFeign2 feign2;
	
	@GetMapping("/getUserId/{userId}")
	@CircuitBreaker(name=CUSTOMER_SERVICE, fallbackMethod = "orderFallback")
	public UserBean getUserId(@PathVariable int userId) {
		UserBean bean = feign.getUserById(userId);
		return bean;
	}
	
	@GetMapping("/getReferral/{referralId}")
	@CircuitBreaker(name=CUSTOMER_SERVICE, fallbackMethod = "orderFallback")
	public ReferralBean getReferral(@PathVariable long referralId) {
	ReferralBean bean = feign2.getReferralById(referralId);
	return bean;
	}
	
	public ResponseEntity<?> orderFallback(Exception e){
        return new ResponseEntity<>("Service is temporarily Down", HttpStatus.OK);

    }
	
}