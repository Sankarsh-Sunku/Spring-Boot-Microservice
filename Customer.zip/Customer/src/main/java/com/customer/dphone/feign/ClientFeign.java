package com.customer.dphone.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.customer.dphone.beans.UserBean;

@FeignClient(name = "feign",url = "http://localhost:8080/user")
public interface ClientFeign {
	@GetMapping("/finduserbyid/{userId}")
	public UserBean getUserById(@PathVariable int userId);

}
