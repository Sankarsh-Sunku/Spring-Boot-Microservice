package com.customer.dphone.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.dphone.beans.CustomerBean;
import com.customer.dphone.beans.UserBean;
import com.customer.dphone.dao.CustomerDao;
import com.customer.dphone.entities.CustomerEntity;

import jakarta.transaction.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerDao dao;
	
 	@Override
	public String addCustomer(CustomerBean customer,UserBean userBean,int referralId) {
		// TODO Auto-generated method stub
 		if(customer!=null) {
 	 	customer.setUserId(userBean.getUserId());
 		customer.setFirstName(userBean.getFirstName());
 		customer.setLastName(userBean.getLastName());
 		customer.setEmail(userBean.getEmail());
 		customer.setMobile(userBean.getMobile());
 		customer.setReferralCode(referralId);
// 		if(referralBean==null) {
// 	 		customer.setReferralCode(0);
// 		}else if(referralBean!=null){
// 	 		customer.setReferralCode(referralId);
// 		}
 		CustomerEntity entity = new CustomerEntity();
 		BeanUtils.copyProperties(customer, entity);
 		dao.save(entity);
		return "Successfully added";
 		}
 		else {
 			return "Check Given Data";
 		}
	}

	@Override
	public String removeCustomer(int customerId) {
		// TODO Auto-generated method stub
		Optional<CustomerEntity> container = dao.findById(customerId);
		if(container.isPresent()) {
			dao.deleteById(customerId);
			return "Customer Deleted Succesfully";
		}else {
			return "No Customer Found";
		}
	}

	@Override
	public CustomerBean getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		Optional<CustomerEntity> container = dao.findById(customerId);
		if(container.isPresent()) {
			CustomerEntity entity = container.get();
			CustomerBean bean = new CustomerBean();
			BeanUtils.copyProperties(entity, bean);
			return bean;
		}else {
			return null;
		}
	}

	@Override
	public String updateCustomerById(int customerId, CustomerBean customer) {
		// TODO Auto-generated method stub
		Optional<CustomerEntity> container = dao.findById(customerId);
		Optional<CustomerEntity> container1 = dao.findById(customer.getCustomerId());
		CustomerEntity entity1 = container.get();
		CustomerEntity entity2 = container1.get();
		
		if(entity1.getCustomerId() == entity2.getCustomerId() && entity2!=null && entity1!=null) {
			entity1.setUserId(customer.getUserId());
			entity1.setFirstName(customer.getFirstName());
			entity1.setLastName(customer.getLastName());
			entity1.setEmail(customer.getEmail());
			entity1.setMobile(customer.getMobile());
			dao.save(entity1);
			return "Updated Successsfully";
		}else {
			return "Check Given CustomerId";
		}
	}

	@Override
	public List<CustomerBean> getAllCustomers() {
		// TODO Auto-generated method stub
		List<CustomerEntity> listEntities = dao.findAll();
		List<CustomerBean> list = new LinkedList<>();
		listEntities.forEach(x -> {
				CustomerBean bean = new CustomerBean();
				BeanUtils.copyProperties(x, bean);
				list.add(bean);
		});
		return list;
	}
	
	@Override
	@Transactional
	public String deleteCustByUserId(int userId) {
		Optional<CustomerEntity> entityOptional = dao.findByUserId(userId);
		if(entityOptional.isPresent()) {
			dao.deleteByUserId(userId);
			return "Successfully deleted";
		}
		else {
			return "check userId once Again";
		}
	}
	
	@Override
	public CustomerBean getCustomerByUserId(int userId) {
		Optional<CustomerEntity> entity = dao.findByUserId(userId);
		CustomerBean bean = new CustomerBean();

		if(entity.isPresent()) {
			BeanUtils.copyProperties(entity.get(), bean);
			return bean;
		}
		else {
			return null;
		}

	}
	
	@Override
	public String updateCustomerByUserId(int userId,CustomerBean bean) {
		CustomerEntity entity1 = dao.findByUserId(userId).get();
		CustomerEntity entity2 = dao.findByUserId(bean.getUserId()).get();
		
		if(entity1.getCustomerId() == entity2.getCustomerId() && entity2!=null && entity1!=null) {
			entity1.setUserId(bean.getUserId());
			entity1.setFirstName(bean.getFirstName());
			entity1.setLastName(bean.getLastName());
			entity1.setEmail(bean.getEmail());
			entity1.setMobile(bean.getMobile());
			dao.save(entity1);
			return "Updated Successsfully";
		}else {
			return "Check Given CustomerId";
		}
		
	}
	
}
