package com.customer.dphone.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.customer.dphone.beans.ReferralBean;

@FeignClient(name = "referralFeign",url = "http://localhost:8086/referral")
public interface ClientFeign2 {
	@GetMapping("/showref/{referralId}")
	public ReferralBean getReferralById(@PathVariable long referralId);
}
