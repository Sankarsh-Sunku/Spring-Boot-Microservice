package com.bajaj.apiGateway.util;

public class AppConstants {
	
	
	//ALL THESE ARE ROUTE ID
	public static final String USER_SERVICE_KEY = "424C481A-DA17-4908-85B1-6740E7808B0D";
    public static final String REFERRAL_SERVICE_KEY = "EE44BAD9-A3DA-46FA-B4E0-7DE7C2681ABF";
    public static final String BUYINGDETAILS_SERVICE_KEY = "EE44BAD9-A3DA-46FA-B4E0-E1GG31THJ5RT";
    public static final String CUSTOMER_SERVICE_KEY = "EE44BAD9-A3DA-46FA-B4E0-T4LO65FFBS76";
    
    //THIS FOR SAVING THE ROUTE IDS
    public static final String RECORD_KEY = "apiKeys";

}
